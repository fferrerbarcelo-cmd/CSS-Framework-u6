// Tema oscuro/claro
const root = document.documentElement;
const themeToggle = document.getElementById("themeToggle");
const themeIcon = document.getElementById("themeIcon");
const themeLabel = document.querySelector(".theme-label");

function applyTheme(theme) {
  root.dataset.theme = theme;
  const isDark = theme === "dark";
  themeIcon.className = isDark ? "bi bi-sun-fill" : "bi bi-moon-stars-fill";
  themeLabel.textContent = isDark ? "Modo claro" : "Modo oscuro";
  themeToggle.setAttribute("aria-label", isDark ? "Cambiar a modo claro" : "Cambiar a modo oscuro");
  document.querySelector('meta[name="theme-color"]').setAttribute("content", isDark ? "#101522" : "#f6f7fb");
}

let savedTheme = "dark";
try {
  savedTheme = localStorage.getItem("portfolio-theme") || "dark";
} catch (error) {
  // Si el navegador bloquea localStorage, el sitio sigue funcionando.
}
applyTheme(savedTheme);

themeToggle.addEventListener("click", () => {
  const nextTheme = root.dataset.theme === "dark" ? "light" : "dark";
  applyTheme(nextTheme);
  try { localStorage.setItem("portfolio-theme", nextTheme); } catch (error) {}
});

// Mini juego: adivinar un número
const guessForm = document.getElementById("guessForm");
const guessInput = document.getElementById("guessInput");
const gameMessage = document.getElementById("gameMessage");
const attemptCount = document.getElementById("attemptCount");
const resetGame = document.getElementById("resetGame");
let secretNumber;
let attempts;
let gameFinished;

function startNewGame() {
  secretNumber = Math.floor(Math.random() * 20) + 1;
  attempts = 0;
  gameFinished = false;
  attemptCount.textContent = attempts;
  gameMessage.textContent = "Elegí un número entre 1 y 20 para empezar.";
  guessInput.value = "";
  guessInput.disabled = false;
  guessForm.querySelector("button").disabled = false;
  guessInput.focus();
}
guessForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const guess = Number(guessInput.value);
  if (!Number.isInteger(guess) || guess < 1 || guess > 20) {
    gameMessage.textContent = "Ingresá un número entero entre 1 y 20.";
    return;
  }
  if (gameFinished) return;
  attempts++;
  attemptCount.textContent = attempts;
  if (guess === secretNumber) {
    gameMessage.textContent = `¡Exacto! Lo encontraste en ${attempts} ${attempts === 1 ? "intento" : "intentos"}. 🎉`;
    gameFinished = true;
    guessInput.disabled = true;
    guessForm.querySelector("button").disabled = true;
  } else if (guess < secretNumber) {
    gameMessage.textContent = "Un poco más alto. ¡Probá de nuevo!";
  } else {
    gameMessage.textContent = "Un poco más bajo. ¡Probá de nuevo!";
  }
  guessInput.select();
});
resetGame.addEventListener("click", startNewGame);
startNewGame();

// Cursor personalizado y efecto al pasar sobre elementos interactivos
const dot = document.querySelector(".cursor-dot");
const outline = document.querySelector(".cursor-outline");
if (window.matchMedia("(pointer:fine)").matches) {
  document.body.classList.add("cursor-active");
  let mouseX = 0, mouseY = 0;
  document.addEventListener("mousemove", (event) => {
    mouseX = event.clientX;
    mouseY = event.clientY;
    dot.style.left = `${mouseX}px`;
    dot.style.top = `${mouseY}px`;
    outline.style.left = `${mouseX}px`;
    outline.style.top = `${mouseY}px`;
  });
  document.querySelectorAll("a, button, input, textarea").forEach((element) => {
    element.addEventListener("mouseenter", () => outline.classList.add("cursor-hover"));
    element.addEventListener("mouseleave", () => outline.classList.remove("cursor-hover"));
  });
}

// Botón volver arriba y año automático
const backToTop = document.getElementById("backToTop");
window.addEventListener("scroll", () => {
  backToTop.classList.toggle("visible", window.scrollY > 450);
}, { passive: true });
backToTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
document.getElementById("currentYear").textContent = new Date().getFullYear();
